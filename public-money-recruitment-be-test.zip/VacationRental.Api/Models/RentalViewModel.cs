﻿namespace VacationRental.Api.Models
{
    public class RentalViewModel
    {
        public int Id { get; set; }
        public int Units { get; set; }
        public int PreparationTimeInDays { get; set; }        
    }
}
