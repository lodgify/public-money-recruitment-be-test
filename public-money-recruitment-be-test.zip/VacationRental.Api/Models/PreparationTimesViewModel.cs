﻿namespace VacationRental.Api.Models
{
    public class PreparationTimesViewModel
    {
        public int Unit { get; set; }
    }
}
