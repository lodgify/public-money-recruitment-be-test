﻿namespace VacationRental.Api.Models
{
    public class ResourceIdViewModel
    {
        public int Id { get; set; }
    }
}
