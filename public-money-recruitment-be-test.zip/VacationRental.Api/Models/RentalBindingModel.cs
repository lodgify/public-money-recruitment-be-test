﻿namespace VacationRental.Api.Models
{
    public class RentalBindingModel
    {
        public int Units { get; set; }
        
        public int PreparationTimeInDays { get; set; }
    }
}
