﻿using System.Collections.Generic;
using VacationRental.Infrastructure.Messaging;

namespace TRSCDS.Application
{
    public class UpdateRentalResponse : ResponseBase
    {        
    }
}
