﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VacationRental.Application
{
    public class RentalService : IRentalService
    {        

    }
}
